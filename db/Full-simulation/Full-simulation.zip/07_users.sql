-- Helldivers-themed users
INSERT INTO User (Img, Pseudo, Name, Email, Password, Last_Login, LanguageID, Creation_Date) VALUES
('https://example.com/super_earth_1.jpg', 'SuperTrooper', 'Alex Johnson', 'alex@super.earth', 'hashedpass1', '2025-04-11', 1, '2024-01-15'),
('https://example.com/helldiver_2.jpg', 'StratagmMaster', 'Maria Garcia', 'maria@super.earth', 'hashedpass2', '2025-04-11', 2, '2024-01-20'),
('https://example.com/liberty_3.jpg', 'LibertyDefender', 'James Wilson', 'james@super.earth', 'hashedpass3', '2025-04-11', 1, '2024-02-01'),
('https://example.com/democracy_4.jpg', 'DemocracySpread', 'Sarah Chen', 'sarah@super.earth', 'hashedpass4', '2025-04-11', 9, '2024-02-15'),
('https://example.com/terminator_5.jpg', 'BugHunter', 'Carlos Rodriguez', 'carlos@super.earth', 'hashedpass5', '2025-04-11', 2, '2024-03-01');