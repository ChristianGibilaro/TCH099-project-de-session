-- Updated with current timestamp
INSERT INTO Notification (Content, Date, Time, Expiration_hours) VALUES
('New team match available!', '2025-04-11', '03:33:57', 24),
('Friend request received', '2025-04-11', '03:33:57', 48),
('Team invitation pending', '2025-04-11', '03:33:57', 72),
('New chat message', '2025-04-11', '03:33:57', 24),
('Achievement unlocked!', '2025-04-11', '03:33:57', 168);